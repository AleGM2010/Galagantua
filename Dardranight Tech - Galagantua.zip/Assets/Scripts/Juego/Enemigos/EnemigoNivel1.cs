using UnityEngine;

public class EnemigoNivel1 : Enemigo, IAcercarse
{
    void Start()
    {
        vida = 100;
        vidaMaxima = vida;
        velocidad = 1.45f;
    }
    public void Acercarse()
    {
        if (jugador != null)
        {
            // Obtener la posici�n del jugador
            Vector3 objetivo = jugador.transform.position;

            // Calcular la direcci�n hacia el objetivo
            Vector3 direccion = (objetivo - transform.position).normalized;

            // Mover el objeto hacia la posici�n del jugador a la velocidad deseada
            transform.position += direccion * velocidad * Time.deltaTime;
        }
    }
    private void Update()
    {
        Acercarse();
        RotacionHaciaElJugador();
    }
}
