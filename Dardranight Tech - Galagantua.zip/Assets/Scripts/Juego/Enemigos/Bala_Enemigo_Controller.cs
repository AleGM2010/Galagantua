using UnityEngine;

public class Bala_Enemigo_Controller : MonoBehaviour
{

    // 360� en 0.5 segundos => 720� por segundo.
    public float rotationSpeed = 720f;

    void FixedUpdate()
    {
        // Rotar alrededor del eje Z
        transform.Rotate(0f, 0f, rotationSpeed * Time.deltaTime);
    }

    private void OnBecameInvisible()
    {
        Destroy(gameObject);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            Destroy(gameObject);
        }
        
    }
}
