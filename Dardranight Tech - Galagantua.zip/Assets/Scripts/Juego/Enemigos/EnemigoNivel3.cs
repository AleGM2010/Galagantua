using UnityEngine;

public class EnemigoNivel3 : Enemigo, IAcercarse, IDisparar
{
    private float distanciaMaxima = 4.5f;  // Distancia m�xima para detenerse
    private float tiempoEntreDisparo = 1.5f;
    private float velBala = 2.5f;
    private float lastShotTime = 0f; // Tiempo del �ltimo disparo
    [SerializeField] private GameObject bala;

    void Start()
    {
        vida = 200;
        vidaMaxima = vida;
        velocidad = .35f;

    }

    // M�todo para acercarse al jugador hasta una distancia m�xima
    public void Acercarse()
    {
        if (jugador != null)
        {
            // Obtener la posici�n del jugador
            Vector3 objetivo = jugador.transform.position;

            // Calcular la direcci�n hacia el objetivo
            Vector3 direccion = (objetivo - transform.position).normalized;

            // Calcular la distancia actual entre el objeto y el jugador
            float distanciaActual = Vector3.Distance(transform.position, jugador.transform.position);

            // Si la distancia es mayor que la distancia m�xima, mover el objeto
            if (distanciaActual > distanciaMaxima)
            {
                // Mover el objeto hacia la posici�n del jugador a la velocidad deseada
                transform.position += direccion * velocidad * Time.deltaTime;
            }
            else
            {
                // Si est� lo suficientemente cerca, no mover
            }
        }
    }


    private void Update()
    {
        Acercarse();
        RotacionHaciaElJugador();

        if (jugador != null)
        {
            // Verifica si ha pasado el intervalo desde el �ltimo disparo
            if (Time.time >= lastShotTime + tiempoEntreDisparo)
            {
                Disparar();
                lastShotTime = Time.time; // Actualiza el tiempo del �ltimo disparo
            }
        }
    }

    public void Disparar()
    {
        // Instanciar la bala en la posici�n de la "punta"
        var b = Instantiate(bala, punta.transform.position, Quaternion.identity);

        // Obtener el componente Rigidbody2D de la bala
        Rigidbody2D rb = b.GetComponent<Rigidbody2D>();
        if (rb != null)
        {
            // Calcular la direcci�n desde la nave hacia la punta
            Vector2 direction = (punta.transform.position - transform.position).normalized;

            // Definir la velocidad inicial de la bala (aj�stala seg�n necesites)
            float bulletSpeed = velBala; // Velocidad en unidades por segundo

            // Aplicar la velocidad en la direcci�n calculada
            rb.linearVelocity = direction * bulletSpeed;
        }
        else
        {
            Debug.LogError("La bala no tiene un componente Rigidbody2D.");
        }
    }
}
