using UnityEngine;

public abstract class Enemigo : MonoBehaviour
{
    protected int vida;
    protected int vidaMaxima;
    protected float velocidad;
    protected int da�oRecibido = 25;
    protected GameObject jugador; // Referencia al jugador
    [SerializeField] protected GameObject barra_de_vida; // Referencia a la barra de vida
    [SerializeField] protected GameObject Efecto_Muerte;
    [SerializeField] private E_EnemigoDestruido eed_;

    protected void OnCollisionEnter2D(Collision2D collision)
    {
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("BalaJugador"))
        {
            RecibirDa�o();
        }
        
    }

    protected virtual void RecibirDa�o()
    {
        vida -= da�oRecibido;
        barra_de_vida.GetComponent<BarraDeVidaController>()?.ReducirVida(vidaMaxima, vida);
        if (vida <= 0)
        {
            Morir();
        }
    }

    protected void Morir()
    {
        StopAllCoroutines();
        eed_.Evento_Enemigo_Destruido.Invoke(gameObject.GetInstanceID());
        Destroy(gameObject);
        Instantiate(Efecto_Muerte, transform.position, Quaternion.identity);
    }

 

    [SerializeField] public Transform punta;   // Punto de referencia para la direcci�n actual


    protected void RotacionHaciaElJugador()
    {
        if (jugador == null || punta == null) return;

        // 1. Direcci�n actual (del enemigo hacia "Punta")
        Vector2 direccionActual = (punta.position - transform.position).normalized;

        // 2. Direcci�n deseada (del enemigo hacia el jugador)
        Vector2 direccionDeseada = (jugador.transform.position - transform.position).normalized;

        // 3. Obtener el �ngulo de ambas direcciones
        float anguloDeseado = Mathf.Atan2(direccionDeseada.y, direccionDeseada.x) * Mathf.Rad2Deg;

        // 4. Aplicar la rotaci�n directamente al enemigo
        transform.rotation = Quaternion.Euler(0, 0, anguloDeseado + 90); 
        // el 90 surge por la posicion original del sprite, ya que el sistema de coordenadas inicia en el 0 y no en -90
    }
 
    public void AsignarJugador(GameObject j)
    {
        jugador = j;
    }
}



