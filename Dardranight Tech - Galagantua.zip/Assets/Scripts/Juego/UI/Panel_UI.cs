using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class Panel_UI : MonoBehaviour
{
    // Eventos
    [SerializeField] private E_JugadorMuerto E_jm;
    [SerializeField] private E_Info_Oleada_toUI eiotUI;
    [SerializeField] private E_JuegoEnPausa ponerjuegoPausa;
    [SerializeField] private E_Victoria victoria;
    // Otras variables
    [SerializeField] private TextMeshProUGUI text_enemigosRestantes;
    [SerializeField] private TextMeshProUGUI text_VidaJugador;
    [SerializeField] private GameObject panelPerdiste;
    [SerializeField] private GameObject panelPausa;
    [SerializeField] private GameObject panelVictoria;
    bool derrotaBool, victoriaBool = false;

    private bool juegoPausa = false;

    void Awake()
    {
        juegoPausa = false;
        E_jm.E_Jugador_Muerto += ActivarPanelPerdiste;
        victoria.CondicionVictoria += ActivarPanelVictoria;
        E_jm.E_VidaRestanteJugador += ActualizarVidaJugador;
        eiotUI.enemigosRestantes += ActualizarEnemigosRestantes_EnUI;
    }
    private void Start()
    {
        panelPerdiste.SetActive(false);
        panelPausa.SetActive(false);
        panelVictoria.SetActive(false);

    }
    // Responsabilidad cuando el jugador muere 

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (!(victoriaBool || derrotaBool))
            {
                JuegoENPausa();
            }
        }
    }

    private void JuegoENPausa()
    {
        juegoPausa = !juegoPausa;
        panelPausa.SetActive(juegoPausa);
        ponerjuegoPausa.E_PonerJuegoENPausa.Invoke(juegoPausa);
        if (juegoPausa)
        {

            Time.timeScale = 0;
        }
        else
        {
            Time.timeScale = 1;

        }

    }
    private void ActivarPanelPerdiste()
    {
        panelPerdiste.SetActive(true);
        derrotaBool = true;
    }

    private void ActivarPanelVictoria()
    {
        panelVictoria.SetActive(true);
        victoriaBool = true;
    }
    // Responsabilidad cuando el GestorDeNiveles envia informacion de oleada
    private void ActualizarEnemigosRestantes_EnUI(int x)
    {
        text_enemigosRestantes.text = "Enemigos restantes: " + x.ToString();
    }

    private void ActualizarVidaJugador(float x)
    {
        text_VidaJugador.text = x.ToString();
    }


    public void OnQuitButtonClicked()
    {
        Application.Quit(); // Cierra la aplicaci�n
        Debug.Log("Aplicaci�n cerrada."); // Solo visible en el Editor
    }
}
