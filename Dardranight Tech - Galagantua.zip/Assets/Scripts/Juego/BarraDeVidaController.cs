using UnityEngine;
using UnityEngine.Rendering;

public class BarraDeVidaController : MonoBehaviour
{
    [SerializeField] private Transform BarraLlena; // Referencia al objeto visual de la barra de vida

    private float escalaActual = 1f; // Valor inicial de escala (lleno)

    private void Awake()
    {
        BarraLlena.localScale = new Vector3(escalaActual, 1f, 1f); // Aplica el cambio de escala
    }
 
    public void ReducirVida(float vidaMaxima, float vida)
    {
        // Aplica el cambio de escala
        var proporcion = vida / vidaMaxima;
        BarraLlena.localScale = new Vector3(Mathf.Max(proporcion,0.0001f), 1f, 1f); 
        // Debug.Log(BarraLlena.localScale.x);
    }

    private Quaternion initialRotation;

    void Start()
    {

        initialRotation = transform.rotation;
    }

    void Update()
    {
        if (transform.parent != null)
        {
            // Mantenemos la rotaci�n inicial del objeto, sin que sea afectada por el movimiento del padre.
            transform.rotation = initialRotation;
        }
    }
}


