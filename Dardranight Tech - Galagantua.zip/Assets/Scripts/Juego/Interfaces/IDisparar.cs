using UnityEngine;

public interface IDisparar
{
    void Disparar();
}
