using UnityEngine;

public interface IAcercarse
{
     void Acercarse();
}
