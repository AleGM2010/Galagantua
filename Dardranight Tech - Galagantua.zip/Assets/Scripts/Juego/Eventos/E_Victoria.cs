using System;
using UnityEngine;

[CreateAssetMenu(fileName = "Victoria", menuName = "Scriptable Objects/Victoria")]
public class E_Victoria : ScriptableObject
{
    public Action CondicionVictoria;
}
