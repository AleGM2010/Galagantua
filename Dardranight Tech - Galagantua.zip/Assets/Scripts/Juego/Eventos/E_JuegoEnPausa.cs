using UnityEngine;
using System;

[CreateAssetMenu(fileName = "E_JuegoEnPausa", menuName = "Scriptable Objects/E_JuegoEnPausa")]
public class E_JuegoEnPausa : ScriptableObject
{
    public Action<bool> E_PonerJuegoENPausa;
}
