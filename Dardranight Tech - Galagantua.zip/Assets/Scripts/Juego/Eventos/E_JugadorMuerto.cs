using UnityEngine;
using System;

[CreateAssetMenu(fileName = "E_JugadorMuerto", menuName = "Scriptable Objects/E_JugadorMuerto")]
public class E_JugadorMuerto : ScriptableObject
{
    public Action E_Jugador_Muerto;
    public Action<float> E_VidaRestanteJugador;
}
