using System;
using UnityEngine;

[CreateAssetMenu(fileName = "E_EnemigoDestruido", menuName = "Scriptable Objects/E_EnemigoDestruido")]
public class E_EnemigoDestruido : ScriptableObject
{
    public Action<int> Evento_Enemigo_Destruido;
}
