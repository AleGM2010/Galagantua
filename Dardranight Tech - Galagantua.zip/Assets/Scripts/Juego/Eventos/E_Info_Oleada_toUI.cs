using System;
using UnityEngine;

[CreateAssetMenu(fileName = "E_Info_Oleada_toUI", menuName = "Scriptable Objects/E_Info_Oleada_toUI")]
public class E_Info_Oleada_toUI : ScriptableObject
{
    public Action<int> enemigosRestantes;
}
