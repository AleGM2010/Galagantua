using System;
using UnityEngine;

[CreateAssetMenu(fileName = "Evento_GuardarDatos", menuName = "Scriptable Objects/Evento_GuardarDatos")]
public class Evento_GuardarDatos : ScriptableObject
{
    public Action GuardarDatos;
}
