using UnityEngine;

public class MovimientoJugador : MonoBehaviour
{
    [SerializeField] private float speed = 2.5f; // Velocidad de movimiento de la nave
    [SerializeField] private float minX = -8f, maxX = 8f, minY = -4f, maxY = 4f; // L�mites de movimiento
    [SerializeField] private E_JuegoEnPausa ponerjuegoPausa;
    private void Awake()
    {
        ponerjuegoPausa.E_PonerJuegoENPausa += JuegoEnPausa;
    }
    private void Update()
    {
       
        Movimiento();

    }
    private void JuegoEnPausa(bool p)
    {
        if (gameObject != null)
        {

            if (p)
            {
                gameObject.SetActive(false);
            }
            else
            {
                gameObject.SetActive(true);
            }
        }
    }
    private void Movimiento()
    {
        // Obtiene la entrada de las teclas WASD
        float horizontalInput = Input.GetAxis("Horizontal"); // A/D
        float verticalInput = Input.GetAxis("Vertical");     // W/S

        // Calcula el vector de movimiento relativo a la nave
        Vector3 movement = new Vector3(horizontalInput, verticalInput, 0f).normalized;

        // Transforma el movimiento al espacio local de la nave
        movement = transform.TransformDirection(movement);

        // Calcula la nueva posici�n sin aplicar a�n los l�mites
        Vector3 newPosition = transform.position + movement * speed * Time.deltaTime;

        // Restringe la posici�n dentro de los l�mites
        newPosition.x = Mathf.Clamp(newPosition.x, minX, maxX);
        newPosition.y = Mathf.Clamp(newPosition.y, minY, maxY);

        // Aplica la nueva posici�n limitada
        transform.position = newPosition;
    }
    void OnDrawGizmos()
    {
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireCube(
            new Vector3((minX + maxX) / 2, (minY + maxY) / 2, transform.position.z),
            new Vector3(maxX - minX, maxY - minY, 0)
        );
    }
}
