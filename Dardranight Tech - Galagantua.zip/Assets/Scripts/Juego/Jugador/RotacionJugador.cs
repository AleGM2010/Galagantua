using UnityEngine;

public class RotacionJugador : MonoBehaviour
{
    private void Update()
    {
        RotacionDelJugador();
    }

    protected void RotacionDelJugador()
    {
        Vector3 mousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        mousePosition.z = 0;
        // Debug.Log(mousePosition);

        // 2. Direcci�n deseada (del enemigo hacia el jugador)
        Vector2 direccionDeseada = (mousePosition - transform.position).normalized;

        // 3. Obtener el �ngulo de ambas direcciones
        float anguloDeseado = Mathf.Atan2(direccionDeseada.y, direccionDeseada.x) * Mathf.Rad2Deg;

        // 4. Aplicar la rotaci�n directamente al enemigo
        transform.rotation = Quaternion.Euler(0, 0, anguloDeseado - 90);
        // el 90 surge por la posicion original del sprite, ya que el sistema de coordenadas inicia en el 0 y no en -90
    }



}
