﻿using UnityEngine;

public class Jugador : MonoBehaviour
{
    [SerializeField] private E_JugadorMuerto E_jm;
    [SerializeField] protected GameObject Efecto_Muerte;
    private float velocidad;
    private float vida;

    // ===================================
   

    void Start()
    {
        vida = 100;
        E_jm.E_VidaRestanteJugador.Invoke(vida);

    }



    #region Mecanica de daño recibido y muerte
    // Para los enemigos que chocaron al jugador
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Enemigo"))
        {
            RecibirDaño();
        }
    }

    // Para las balas enemias
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("BalaEnemigo"))
        {
            RecibirDaño();

        }
    }
    protected virtual void RecibirDaño()
    {
        vida -= 10;
        E_jm.E_VidaRestanteJugador.Invoke(vida);
        // Debug.Log($"Recibimos 10 de daño, quedan {vida} puntos de vida");
        if (vida <= 0)
        {
            Morir();
        }
    }

    protected void Morir()
    {
        StopAllCoroutines();
        Destroy(gameObject);
        E_jm.E_Jugador_Muerto.Invoke();
        Instantiate(Efecto_Muerte, transform.position, Quaternion.identity);
    }

    #endregion

    #region Datos para sistema de guardado

     // Importante: Este objeto tiene un padre que lo "mueve" por lo que aunque tomemos la posicion
     // y esto signifique que es la absoluta (por como unity funciona), al modificar no es a este objeto, sino al padre
    public float pedirVida()
    {
        return vida;

    }
    public float pedirVelocidad()
    {
        return velocidad;
    }
    public Vector3 pedirPosition()
    {
        return transform.position;
    }
    public Quaternion pedirRotation()
    {
        return transform .rotation;
    }
    public Vector3 pedirScale()
    {
        return transform.localScale;
    }

    public void asignarVida(float nuevaVida)
    {
        vida = nuevaVida;
        E_jm.E_VidaRestanteJugador.Invoke(vida);

    }

    public void asignarVelocidad(float nuevaVelocidad)
    {
        velocidad = nuevaVelocidad;
    }

    public void asignarPosition(Vector3 nuevaPosicion)
    {
        transform.parent.position = nuevaPosicion;
    }

    public void asignarRotation(Quaternion nuevaRotacion)
    {
        transform.parent.rotation = nuevaRotacion;
    }

    public void asignarScale(Vector3 nuevaEscala)
    {
        transform.parent.localScale = nuevaEscala;
    }



    #endregion
 
}
