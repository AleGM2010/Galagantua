using UnityEngine;

public class BalaJugador : MonoBehaviour
{

    public float rotationSpeed = 360f;

    void FixedUpdate()
    {
        // Rotar alrededor del eje Z
         transform.Rotate(0f, rotationSpeed * Time.deltaTime,0f);
    }


    private void OnBecameInvisible()
    {
        Destroy(gameObject);
    }

    
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Enemigo"))
        {
            Destroy(gameObject);
            //    Debug.Log("paso trigger BJ");
        }

    }
}
