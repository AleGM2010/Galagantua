﻿using UnityEngine;
using UnityEngine.InputSystem;

public class Jug_Disparar : MonoBehaviour
{
    [SerializeField] private E_JuegoEnPausa ponerjuegoPausa;
    [SerializeField] public Transform punta;   // Punto de referencia para la dirección actual
    [SerializeField] private float tiempoEntreDisparo = 2f;
    private float lastShotTime = 0f; // Tiempo del �ltimo disparo
    private float velBala = 5f;
    [SerializeField] private GameObject bala;
    private void Awake()
    {
        ponerjuegoPausa.E_PonerJuegoENPausa += JuegoEnPausa;
    }
    void Update()
    {
        if (Input.GetMouseButton(0))
        {
            // Verifica si ha pasado el intervalo desde el �ltimo disparo
            if (Time.time >= lastShotTime + tiempoEntreDisparo)
            {
                Disparar();
                lastShotTime = Time.time; // Actualiza el tiempo del �ltimo disparo
            }
        }
    }
    private void JuegoEnPausa(bool p)
    {
        if (gameObject != null)
        {

            if (p)
            {
                gameObject.SetActive(false);
            }
            else
            {
                gameObject.SetActive(true);
            }
        }
    }
    public void Disparar()
    {
        // Instanciar la bala en la posición de la "punta"
        var b = Instantiate(bala, punta.transform.position, Quaternion.identity);
        b.transform.rotation = transform.rotation; // Mantener la rotación de la nave

        // Obtener el componente Rigidbody2D de la bala
        Rigidbody2D rb = b.GetComponent<Rigidbody2D>();
        if (rb != null)
        {
            // Calcular la dirección desde la nave hacia la punta y normalizarla
            Vector2 direction = (punta.transform.position - transform.position).normalized;
            // Debug.Log("Dirección normalizada: " + direction);

            // Definir la velocidad inicial de la bala
            float bulletSpeed = velBala; // Usar la variable velBala que ya tienes definida

            // Asignar la velocidad directamente al Rigidbody2D
            rb.linearVelocity = direction * bulletSpeed;
        }
        else
        {
            Debug.LogError("La bala no tiene un componente Rigidbody2D.");
        }
    }
}
