using UnityEngine;
using System.Collections.Generic;
public class ListaEnemigos : MonoBehaviour
{

    [SerializeField] private List<GameObject> prefabs_enemigos_list;

    private void Start()
    {    
         //  Debug.Log("Prefabs cargados:" + prefabs_enemigos_list.Count);

        // Debug.Log("prefab aleatorio:" + PrefabAleatorio_DeEnemigo());

    }
    public List<GameObject> Obtener_ListaEnemigos()
    {
        if (prefabs_enemigos_list.Count > 0){
            return prefabs_enemigos_list;
        }
        return null;
    }
    public GameObject PrefabAleatorio_DeEnemigo()
    {
        return prefabs_enemigos_list[Random.Range(0, prefabs_enemigos_list.Count)];
    }
}
