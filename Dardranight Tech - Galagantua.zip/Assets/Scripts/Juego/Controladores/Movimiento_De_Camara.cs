using UnityEngine;

public class Movimiento_De_Camara : MonoBehaviour
{
    [SerializeField] private float smoothTime = 0.3f;       // Tiempo de suavizado
    [SerializeField] private Vector2 minBounds = new Vector2(-10f, -10f); // L�mite inferior global (X min, Y min)
    [SerializeField] private Vector2 maxBounds = new Vector2(10f, 10f);   // L�mite superior global (X max, Y max)
    [SerializeField] private Vector2 cameraEdgeOffset = new Vector2(5f, 5f); // Offset relativo para los bordes de activaci�n
    [SerializeField] private Transform target;              // Referencia al personaje que debe permanecer visible

    private Camera mainCamera;
    private Vector3 velocity = Vector3.zero;               // Velocidad para SmoothDamp
    private Vector2 originalPosition;

    void Awake()
    {
        originalPosition = transform.position;
    }

    void Start()
    {
        mainCamera = Camera.main;
        if (mainCamera == null)
        {
            Debug.LogError("No se encontr� la c�mara principal.");
            enabled = false;
        }
        if (target == null)
        {
            Debug.LogError("No se asign� un personaje (target) en el Inspector.");
        }
    }

    void Update()
    {
        if (mainCamera == null || target == null) return;

        // Obtener la posici�n del mouse en coordenadas del mundo
        Vector3 mousePosition = mainCamera.ScreenToWorldPoint(Input.mousePosition);
        mousePosition.z = transform.position.z; // Mantener la Z fija

        // Verificar si la c�mara debe moverse seg�n los bordes din�micos
        Vector3 targetPosition = transform.position;
        if (Bool_MoverCamara(mousePosition))
        {
            // Definir la posici�n objetivo dentro de los l�mites globales
            targetPosition = new Vector3(
                Mathf.Clamp(mousePosition.x, minBounds.x, maxBounds.x),
                Mathf.Clamp(mousePosition.y, minBounds.y, maxBounds.y),
                transform.position.z
            );
        }

        // Ajustar los l�mites para mantener al personaje visible
        AdjustBoundsForTarget(ref targetPosition);

        // Mover la c�mara hacia la posici�n objetivo con suavizado
        transform.position = Vector3.SmoothDamp(transform.position, targetPosition, ref velocity, smoothTime);
    }

    private bool Bool_MoverCamara(Vector3 mousePosition)
    {
        // Calcular los l�mites din�micos basados en la posici�n actual de la c�mara
        Vector2 currentCameraPos = transform.position;
        Vector2 minBoundsCamera = currentCameraPos - cameraEdgeOffset;
        Vector2 maxBoundsCamera = currentCameraPos + cameraEdgeOffset;

        // Borde izquierdo
        if (mousePosition.x < minBoundsCamera.x)
        {
            return true;
        }
        // Borde derecho
        else if (mousePosition.x > maxBoundsCamera.x)
        {
            return true;
        }

        // Borde inferior
        if (mousePosition.y < minBoundsCamera.y)
        {
            return true;
        }
        // Borde superior
        else if (mousePosition.y > maxBoundsCamera.y)
        {
            return true;
        }
        return false;
    }

    private void AdjustBoundsForTarget(ref Vector3 targetPosition)
    {
        if (target == null) return;

        // Calcular el tama�o visible de la c�mara (para modo ortogr�fico)
        float cameraHeight = mainCamera.orthographicSize;
        float cameraWidth = cameraHeight * mainCamera.aspect;

        // Asegurarse de que el personaje no salga de la vista
        Vector3 targetPos = target.position;
        float minX = targetPos.x - cameraWidth + 1f;  // Margen de 1 unidad para mantenerlo visible
        float maxX = targetPos.x + cameraWidth - 1f;
        float minY = targetPos.y - cameraHeight + 1f;
        float maxY = targetPos.y + cameraHeight - 1f;

        // Combinar con los l�mites globales
        minX = Mathf.Max(minX, minBounds.x);
        maxX = Mathf.Min(maxX, maxBounds.x);
        minY = Mathf.Max(minY, minBounds.y);
        maxY = Mathf.Min(maxY, maxBounds.y);

        // Aplicar los l�mites ajustados
        targetPosition.x = Mathf.Clamp(targetPosition.x, minX, maxX);
        targetPosition.y = Mathf.Clamp(targetPosition.y, minY, maxY);
    }

    void OnDrawGizmos()
    {
        // Gizmo para los l�mites globales (rojo)
        Gizmos.color = Color.red;
        Gizmos.DrawWireCube(
            new Vector3((minBounds.x + maxBounds.x) / 2, (minBounds.y + maxBounds.y) / 2, transform.position.z),
            new Vector3(maxBounds.x - minBounds.x, maxBounds.y - minBounds.y, 0)
        );

        // Gizmo para los bordes din�micos de activaci�n (verde)
        Gizmos.color = Color.green;
        Vector2 currentCameraPos = transform.position;
        Vector2 minBoundsCamera = currentCameraPos - cameraEdgeOffset;
        Vector2 maxBoundsCamera = currentCameraPos + cameraEdgeOffset;
        Gizmos.DrawWireCube(
            new Vector3((minBoundsCamera.x + maxBoundsCamera.x) / 2, (minBoundsCamera.y + maxBoundsCamera.y) / 2, transform.position.z),
            new Vector3(maxBoundsCamera.x - minBoundsCamera.x, maxBoundsCamera.y - minBoundsCamera.y, 0)
        );
    }
}