using System.Collections.Generic;
using System.Collections;
using UnityEngine;
using System.Linq;

public class GestorNiveles : MonoBehaviour
{
    // Eventos
    [SerializeField] private E_EnemigoDestruido eed_;
    [SerializeField] private E_Info_Oleada_toUI eiotUI;
    [SerializeField] private E_Victoria nivelSuperado;

    // Otras variables
    [SerializeField] private ListaEnemigos l_enemigos;              // Lista de prefabs de enemigos
    [SerializeField] private ListaRespawnsEnemigos l_r_enemigos;   // Lista de posiciones de respawn
    private List<int> lista_ID_enemigosVivos;                  // Lista de enemigos actualmente vivos
    [SerializeField] private GameObject jugador;                    // Para crear enemigos necesito al jugador para referenciarlos
    [SerializeField] private float tiempoEntreGeneraciones = 2f;   // Tiempo entre cada generaci�n (t1)
    [SerializeField] private int cantEnemigosMaxAlaVez = 5;        // M�ximo de enemigos vivos al mismo tiempo
    [SerializeField] private int cantEnemigosPorOleada = 10;       // Total de enemigos por oleada
    private int enemigosActuales = 0;                              // Contador de enemigos vivos
    private int enemigosCreados = 0;                               // Contador de enemigos creados en la oleada
    private int enemigosRestantes;

    void Awake()
    {
        enemigosRestantes = cantEnemigosPorOleada;
        eed_.Evento_Enemigo_Destruido += EnemigoDestruido;
        lista_ID_enemigosVivos = new List<int>();              // Inicializa la lista de enemigos vivos
    }
    private void Start()
    {
        eiotUI.enemigosRestantes.Invoke(cantEnemigosPorOleada); // Actualiza cantidad de enemigos restantes
        StartCoroutine(GenerarOleada());
    }

    // Corrutina para generar enemigos hasta completar la oleada
    private IEnumerator GenerarOleada()
    {
        yield return new WaitForSeconds(1); // Por gestion de datos y sincronizacion, espero 2 seg
        while (enemigosCreados < cantEnemigosPorOleada)            // Contin�a hasta alcanzar el total de la oleada
        {
            CrearEnemigoAleatorio();                               // Intenta crear un enemigo
            yield return new WaitForSeconds(tiempoEntreGeneraciones); // Espera el tiempo especificado
        }

        // ========> Aqui habra terminado la corrutina, es decir la Oleada PERO no necesariamente los enemigos muertos
        // eso seria ya con la lista de enemigos vacia
    }
    // M�todo para crear un enemigo en una posici�n aleatoria
    private void CrearEnemigoAleatorio()
    {
        if (enemigosCreados >= cantEnemigosPorOleada) return;      // No crea m�s si se alcanz� el l�mite de la oleada
        if (enemigosActuales >= cantEnemigosMaxAlaVez) return;     // No crea m�s si hay demasiados vivos

        var e_ = l_enemigos.PrefabAleatorio_DeEnemigo();
        var p_ = l_r_enemigos.Posicion_Aleatoria();
        CrearEnemigo(e_, p_);
    }

    // M�todo que genera un enemigo en una posici�n espec�fica
    private void CrearEnemigo(GameObject e, Vector2 p)
    {
        GameObject enemigo = Instantiate(e, p, Quaternion.identity);
        enemigo.GetComponent<Enemigo>().AsignarJugador(jugador);            // Asigno el objetivo y la maldad programada
        lista_ID_enemigosVivos.Add(enemigo.GetInstanceID());                // A�ade el id del enemigo a la lista de vivos
        enemigosCreados++;                                         // Incrementa el contador de creados
        enemigosActuales++;                                        // Incrementa el contador de vivos
    }


    // M�todo para actualizar el conteo de enemigos vivos (llamar cuando un enemigo muere)
    public void EnemigoDestruido(int id_enemigo)
    {
        if (lista_ID_enemigosVivos.Contains(id_enemigo))
        {
            lista_ID_enemigosVivos.Remove(id_enemigo);                     // Elimina al enemigo de la lista
            enemigosActuales--;               // Reduce el contador de vivos
            eiotUI.enemigosRestantes.Invoke(--enemigosRestantes);      // Actualiza cantidad de enemigos restantes
        }

        if (enemigosRestantes == 0)
        {
            nivelSuperado.CondicionVictoria.Invoke();
        }
    }



}