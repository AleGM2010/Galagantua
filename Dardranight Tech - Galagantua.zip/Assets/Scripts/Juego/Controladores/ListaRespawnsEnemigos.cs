using System.Collections.Generic;
using UnityEngine;

public class ListaRespawnsEnemigos : MonoBehaviour
{

    [SerializeField] private List<GameObject> posiciones_respawns_enemigos_list;
    private List<Vector2> posiciones = new List<Vector2> { }; // No es un objeto, necesita inicializarse
    private void Start()
    {
        foreach (var elem in posiciones_respawns_enemigos_list)
        {
            posiciones.Add(new Vector2(elem.transform.position.x, elem.transform.position.y));
        }
        foreach (var elem in posiciones)
        {
            // Debug.Log("Posiciones:"+elem);
        }
     //   Debug.Log("Posiciones aleatoria:" + Posicion_Aleatoria());

    }
    public List<Vector2> Obtener_ListaEnemigos()
    {
        if (posiciones.Count > 0)
        {
            return posiciones;
        }
        return null;
    }

    public Vector2 Posicion_Aleatoria()
    {     
           return posiciones[Random.Range(0, posiciones.Count)];
        
    }
}
