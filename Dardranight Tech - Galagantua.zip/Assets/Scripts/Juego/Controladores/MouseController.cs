﻿using UnityEngine;

public class MouseController : MonoBehaviour
{
    public float rotationSpeed = 120f;
    private void Start()
    {
        transform.position = Vector3.zero;
    }

    void Update()
    {
        // Obtener la posición del mouse en el mundo
        Vector3 mouseWorldPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        mouseWorldPos.z = 5;
       // Debug.Log(mouseWorldPos);
        transform.position = mouseWorldPos;

        transform.Rotate(0f, 0f, rotationSpeed * Time.deltaTime);
    }
}
