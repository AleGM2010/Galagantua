using UnityEngine;

public class Explocion_controller : MonoBehaviour
{
   
    private void OnDestroy()
    {
         StopAllCoroutines();
         Destroy(gameObject);
    }
}
