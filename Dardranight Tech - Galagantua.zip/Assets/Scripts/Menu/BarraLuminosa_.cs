using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class BarraLuminosa_ : MonoBehaviour
{
    // Referencia a la componente Image
    private Image imagen;
    // Color original de la imagen (incluye alpha)
    private Color colorOriginal;
    // Duraci�n del parpadeo 
    public float cicloDuracion = 3f;


    void Start()
    {
        // Obtener la referencia a la componente Image del objeto
        imagen = GetComponent<Image>();
        if (imagen != null)
        {
            // Guardar el color original
            colorOriginal = imagen.color;
            // Iniciar la corrutina de parpadeo
            StartCoroutine(Parpadear());
        }
        else
        {
            Debug.LogError("No se encontr� componente Image en " + gameObject.name);
        }
    }

    // Corrutina para el efecto de parpadeo suave
    // Corrutina que realiza un fade in y fade out suave usando LERP
    private IEnumerator Parpadear()
    {
        // Calculamos la duraci�n de cada fase (fade in y fade out)
        float duracionFase = cicloDuracion / 2f;

        while (true)
        {
            // Fade In: de 0 a 1
            float timer = 0f;
            while (timer < duracionFase)
            {
                timer += Time.deltaTime;
                float t = timer / duracionFase; // Valor entre 0 y 1
                float nuevoAlpha = Mathf.Lerp(0f, 1f, t);
                imagen.color = new Color(colorOriginal.r, colorOriginal.g, colorOriginal.b, nuevoAlpha);
                yield return null;
            }

            // Fade Out: de 1 a 0
            timer = 0f;
            while (timer < duracionFase)
            {
                timer += Time.deltaTime;
                float t = timer / duracionFase;
                float nuevoAlpha = Mathf.Lerp(1f, 0f, t);
                imagen.color = new Color(colorOriginal.r, colorOriginal.g, colorOriginal.b, nuevoAlpha);
                yield return null;
            }
        }
    }

}

