
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class MenuInicial : MonoBehaviour
{
    [SerializeField] private Button playButton; // Referencia al bot�n "Play"
    [SerializeField] private Button quitButton; // Referencia al bot�n "Quit"

    void Start()
    {
        // Asegurarse de que los botones est�n asignados y agregar listeners
        if (playButton != null)
        {
            playButton.onClick.AddListener(OnPlayButtonClicked);
        }
        else
        {
            Debug.LogError("El bot�n 'Play' no est� asignado en el Inspector.");
        }

        if (quitButton != null)
        {
            quitButton.onClick.AddListener(OnQuitButtonClicked);
        }
        else
        {
            Debug.LogError("El bot�n 'Quit' no est� asignado en el Inspector.");
        }
    }

    // M�todo para el bot�n "Play"
    private void OnPlayButtonClicked()
    {
        SceneManager.LoadScene("Juego"); // Carga la escena llamada "Juego"
    }

    // M�todo para el bot�n "Quit"
    private void OnQuitButtonClicked()
    {
        Application.Quit(); // Cierra la aplicaci�n
        Debug.Log("Aplicaci�n cerrada."); // Solo visible en el Editor
    }
}