using UnityEngine;

public class Datos_Jugador : MonoBehaviour
{
    [SerializeField] private Jugador jugador;

    public float velocidad;
    public float vida;

    public Vector3 position;
    public Quaternion rotation;
    public Vector3 scale;

    public void ExtraerDatosDelJugador()
    {
        vida = jugador.pedirVida();
        velocidad = jugador.pedirVelocidad();
        position = jugador.pedirPosition();
        rotation = jugador.pedirRotation();
        scale = jugador.pedirScale();
    }

    public void RestaurarDatos()
    {
        jugador.asignarVida(vida);
        jugador.asignarVelocidad(velocidad);
        jugador.asignarPosition(position);
        jugador.asignarRotation(rotation);
        jugador.asignarScale(scale);
    }
}
