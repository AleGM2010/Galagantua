using UnityEngine;
using System.IO;

public class SaveSystem : MonoBehaviour
{
    private string savePath;

    void Awake()
    {
        savePath = Path.Combine(Application.persistentDataPath, "savefile.dat");
    }

    public void SaveGame(GameData data)
    {
        // Convierte los datos a JSON
        string json = JsonUtility.ToJson(data);
        // Encripta el JSON
        string encrypted = Encryption.Encrypt(json);
        // Guarda el texto encriptado
        File.WriteAllText(savePath, encrypted);
    }

    public GameData LoadGame()
    {
        if (File.Exists(savePath))
        {
            // Lee el texto encriptado
            string encrypted = File.ReadAllText(savePath);
            // Desencripta el texto
            string json = Encryption.Decrypt(encrypted);
            // Convierte el JSON a GameData
            return JsonUtility.FromJson<GameData>(json);
        }
        return null; // Si no hay archivo, devuelve null
    }
}