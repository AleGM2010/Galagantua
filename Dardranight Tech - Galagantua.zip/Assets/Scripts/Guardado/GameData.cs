using UnityEngine;

[System.Serializable]
public class GameData
{

    public float velocidad_Jugador;
    public float vida_Jugador;

    public Vector3 position_Jugador;
    public Quaternion rotation_Jugador;
    public Vector3 scale_Jugador;






}