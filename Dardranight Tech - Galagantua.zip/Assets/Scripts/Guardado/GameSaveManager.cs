using System.IO;
using System.Runtime.CompilerServices;
using UnityEngine;

public class GameSaveManager : MonoBehaviour
{
    [SerializeField] private GameObject saveSystemInstance;
    private SaveSystem saveSystem;
    [SerializeField] private Datos_Jugador datos_delJugador;
    private GameData gameData;

    void Start()
    {
        saveSystem = saveSystemInstance.GetComponent<SaveSystem>();
        gameData = saveSystem.LoadGame();

        if (gameData == null)
        {
            // Si no hay datos guardados, crea nuevos con valores iniciales
            gameData = new GameData
            {
                velocidad_Jugador = 2f,
                vida_Jugador = 100f,
            };
        }
    }
    private void Update()
    {

        if (Input.GetKeyDown(KeyCode.E))
        {
            File.WriteAllText(Path.Combine(Application.persistentDataPath, "test.txt"), "Test data");
            Debug.Log("txt");
        }
    }
    public void Save()
    {
        // Actualiza los datos con el estado actual del juego
        UpdateGameData();
        saveSystem.SaveGame(gameData);
        Debug.Log("Save");
        
    }

    private void UpdateGameData()
    {
        // Aqu� actualizas gameData con los valores actuales del juego
       datos_delJugador.ExtraerDatosDelJugador(); // Actualizar datos dentro de datosDelJugador

        gameData.vida_Jugador = datos_delJugador.vida; 
        gameData.velocidad_Jugador = datos_delJugador.velocidad;
        gameData.position_Jugador = datos_delJugador.transform.position;
        gameData.rotation_Jugador = datos_delJugador.transform.rotation;
        gameData.scale_Jugador = datos_delJugador.transform.localScale;


    }

    public void ApplyGameData()
    {
        Debug.Log("Load");

        // Aplica los datos cargados al jugador
        datos_delJugador.RestaurarDatos();
        datos_delJugador.vida = gameData.vida_Jugador; 
        datos_delJugador.velocidad = gameData.velocidad_Jugador;   
        datos_delJugador.transform.position = gameData.position_Jugador;
        datos_delJugador.transform.rotation = gameData.rotation_Jugador;
        datos_delJugador.transform.localScale = gameData.scale_Jugador;
    }
}